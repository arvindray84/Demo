package zillow.bean;

public class OneWeekChange {
	private String deprecated;

	public String getDeprecated() {
		return deprecated;
	}

	public void setDeprecated(String deprecated) {
		this.deprecated = deprecated;
	}

	@Override
	public String toString() {
		return "ClassPojo [deprecated = " + deprecated + "]";
	}
}
